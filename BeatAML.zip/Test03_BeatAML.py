# -*- coding: utf-8 -*-
"""
Created on Sat Mar 14 17:28:20 2020

@author: SRDhruba
"""


#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import os
import numpy as np
import pandas as pd
import pickle
from time import time
from tqdm import tqdm
# from skrebate import ReliefF
from sklearn.preprocessing import StandardScaler
# from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR as SupportVectorRegressor
from sklearn.linear_model import Lasso, LassoCV, ElasticNet
from sklearn.neighbors import KNeighborsRegressor
from scipy.stats import pearsonr, spearmanr

## Path & FILE...
PATH = "%s\\Google Drive\\Study\\ECE 5332-009 - Topics in EE, Data Science\\BeatAML\\" % os.getenv("HOMEPATH")
DIR  = ("Training\\", "Leaderboard\\")
FILE = ("rnaseq.csv", "dnaseq.csv", "clinical_numerical.csv", "clinical_categorical.csv", 
        "clinical_categorical_legend.csv", "aucs.csv", "response.csv")
os.chdir(PATH)

### Training data...
RNA_TR = pd.read_csv(PATH + DIR[0] + FILE[0], header = 0)
AUC_TR = pd.read_csv(PATH + DIR[0] + FILE[5], header = 0)

## Leaderboard data...
RNA_LB = pd.read_csv(PATH + DIR[1] + FILE[0], header = 0)
AUC_LB = pd.read_csv(PATH + DIR[1] + FILE[5], header = 0)

all(AUC_TR.inhibitor.unique()  == AUC_LB.inhibitor.unique())     ## Check if same drugs
all(RNA_TR[["Gene", "Symbol"]] == RNA_LB[["Gene", "Symbol"]])    ## Check if same genes

lab_id_list = dict(TR = RNA_TR.columns, LB = RNA_LB.columns)
gene_list, drug_list = RNA_TR[["Gene", "Symbol"]], AUC_TR.inhibitor.unique().tolist()

## Preprocessing...
RNA_TR.index, RNA_LB.index = gene_list.Symbol, gene_list.Symbol
RNA_TR, RNA_LB = RNA_TR.iloc[:, 2:], RNA_LB.iloc[:, 2:]
# print(RNA_TR.shape, RNA_LB.shape)

var_idx = (-RNA_TR.var(axis = 1)).to_numpy().argsort()[:40000]   ## Filter by gene variability
RNA_TR_filt, RNA_LB_filt = RNA_TR.iloc[var_idx, :], RNA_LB.iloc[var_idx, :]


# In[ ]:


## Scaling...
zscore = lambda data, ref_data: StandardScaler().fit(ref_data).transform(data)

## Feature selection...
def LassoFS(X, y, seed = 0):
    # FS = LassoCV(fit_intercept = True, normalize = False, n_alphas = 100, tol = 1e-3, cv = 5, selection = "random", 
    #              random_state = seed, n_jobs = -1)
    # FS = Lasso(fit_intercept = True, normalize = False, alpha = 0.001, tol = 1e-3, selection = "random", random_state = seed)
    FS  = Lasso(fit_intercept = True, normalize = False, alpha = 0.001, selection = 'random', random_state = seed, max_iter = 3000)
    features = (FS.fit(X, y).coef_ != 0).nonzero()[0]
    return features


## Predictive models...
def RF(X_train, y_train, X_test, seed = 0):
    mdl = RandomForestRegressor(n_estimators = 200, criterion = "mae", min_samples_leaf = 5, random_state = seed, n_jobs = -1)
    y_pred = mdl.fit(X_train, y_train).predict(X_test)
    return y_pred

def SVR(X_train, y_train, X_test):
    mdl = SupportVectorRegressor(kernel = "poly", degree = 3, coef0 = 1.0, gamma = "scale", tol = 1e-3, C = 10, max_iter = 2000)
    y_pred = mdl.fit(X_train, y_train).predict(X_test)
    return y_pred

def EN(X_train, y_train, X_test, seed):
    mdl = ElasticNet(fit_intercept = True, l1_ratio = 0.005, alpha = 0.2, tol = 1e-3, max_iter = 2000, selection = "random", 
                     random_state = seed)
    y_pred = mdl.fit(X_train, y_train).predict(X_test)
    return y_pred

def KNN(X_train, y_train, X_test):
    mdl = KNeighborsRegressor(n_neighbors = 5, weights = "distance", algorithm = "auto", metric = "minkowski", p = 1, n_jobs = -1)
    y_pred = mdl.fit(X_train, y_train).predict(X_test)
    return y_pred


## Evaluate model performance...
def EVAL_PERF(y_label, y_pred, alpha = 0.05):
    y_label, y_pred = np.array(y_label).squeeze(), np.array(y_pred).squeeze()
    PCC, pval = pearsonr(y_label, y_pred);     #PCC = PCC if pval < alpha else 0
    SCC, pval = spearmanr(y_label, y_pred);    #SCC = SCC if pval < alpha else 0
    NRMSE = np.sqrt(((y_label - y_pred)**2).mean()) / y_label.std(ddof = 0)
    NMAE  = (np.abs(y_label - y_pred)).mean() / (np.abs(y_label - y_label.mean())).mean()
    return PCC, SCC, NRMSE, NMAE


# In[ ]

### TEST ON LEADERBOARD DATA...
FS_switch = "ReliefF"
if FS_switch == "ReliefF":
    p_top = 30000
    # feature_ranks = {kk: [ ] for kk in drug_list}
    with open("FS_Drugs_122_ReliefF_3_folds.pickle", "rb") as file:
        feature_ranks = pickle.load(file)
elif FS_switch == "Lasso":
    feature_ranks = dict.fromkeys(drug_list)
####

AUC_LB_pred = { };      metrics = ["PCC", "SCC", "NRMSE", "NMAE"]
models = ["RF", "SVR", "EN", "KNN", "ENS", "ENS12", "ENS123", "ENS124", "ENS134", "ENS234"]
RESULTS_LB_RF     = pd.DataFrame(dtype = float, index = drug_list, columns = metrics)
RESULTS_LB_SVR    = pd.DataFrame(dtype = float, index = drug_list, columns = metrics)
RESULTS_LB_EN     = pd.DataFrame(dtype = float, index = drug_list, columns = metrics)
RESULTS_LB_KNN    = pd.DataFrame(dtype = float, index = drug_list, columns = metrics)
RESULTS_LB_ENS    = pd.DataFrame(dtype = float, index = drug_list, columns = metrics)
RESULTS_LB_ENS12  = pd.DataFrame(dtype = float, index = drug_list, columns = metrics)
RESULTS_LB_ENS123 = pd.DataFrame(dtype = float, index = drug_list, columns = metrics)
RESULTS_LB_ENS124 = pd.DataFrame(dtype = float, index = drug_list, columns = metrics)
RESULTS_LB_ENS134 = pd.DataFrame(dtype = float, index = drug_list, columns = metrics)
RESULTS_LB_ENS234 = pd.DataFrame(dtype = float, index = drug_list, columns = metrics)

N = len(drug_list);     count = 0
dt = time() 
for drug in tqdm(drug_list[:N]):
    count += 1;   # print("\nChosen drug# = %d: %s" % (count, drug))
    
    y_TR = AUC_TR.iloc[(AUC_TR.inhibitor == drug).tolist(), :]
    y_LB = AUC_LB.iloc[(AUC_LB.inhibitor == drug).tolist(), :]
    X_TR, y_TR = RNA_TR_filt.loc[:, y_TR.lab_id].T, y_TR["auc"].to_numpy()
    X_LB, y_LB = RNA_LB_filt.loc[:, y_LB.lab_id].T, y_LB["auc"].to_numpy()
    
    Y_LB_pred = pd.DataFrame(dtype = float, index = X_LB.index, columns = ["Actual"] + models)
    
    fold = 0;      # dt = time()
    # ## Perform ReliefF...
    # dt = time();        FS.fit(X_TR.values, y_TR);      dt = time() - dt;    print("Elapsed time = %0.4f sec." % dt)
    # feat_top = FS.top_features_;    feature_ranks[drug].append(feat_top)

    ## From saved file...
    if FS_switch == "ReliefF":
        feat_top_set = feature_ranks[drug][fold]
        feat_top = feat_top_set[:p_top]
    elif FS_switch == "Lasso":
        feat_top = LassoFS(X_TR, y_TR, seed = 2020)
        feature_ranks[drug] = feat_top
    X_TR, X_LB = X_TR.iloc[:, feat_top], X_LB.iloc[:, feat_top]
    
    ## Perform prediction...
    Y_LB_pred.loc[:, "Actual"] = y_LB
    Y_LB_pred.loc[:, "RF"]     =  RF(X_TR, y_TR, X_LB, seed = 0)
    Y_LB_pred.loc[:, "SVR"]    = SVR(X_TR, y_TR, X_LB)
    Y_LB_pred.loc[:, "EN"]     =  EN(X_TR, y_TR, X_LB, seed = 0)
    Y_LB_pred.loc[:, "KNN"]    = KNN(X_TR, y_TR, X_LB)
    # fold += 1
    # dt = time() - dt;    print("Elapsed time = %0.4f sec." % dt)
        
    ## Ensemble prediction...
    Y_LB_pred.loc[:, "ENS"]    = Y_LB_pred.loc[:, ["RF", "SVR", "EN", "KNN"]].mean(axis = 1)
    Y_LB_pred.loc[:, "ENS12"]  = Y_LB_pred.loc[:, ["RF", "SVR"]].mean(axis = 1)
    Y_LB_pred.loc[:, "ENS123"] = Y_LB_pred.loc[:, ["RF", "SVR", "EN" ]].mean(axis = 1)
    Y_LB_pred.loc[:, "ENS124"] = Y_LB_pred.loc[:, ["RF", "SVR", "KNN"]].mean(axis = 1)
    Y_LB_pred.loc[:, "ENS134"] = Y_LB_pred.loc[:, ["RF", "EN",  "KNN"]].mean(axis = 1)
    Y_LB_pred.loc[:, "ENS234"] = Y_LB_pred.loc[:, ["SVR", "EN", "KNN"]].mean(axis = 1)
    AUC_LB_pred[drug] = Y_LB_pred
    
    ## Save results...
    RESULTS_LB_RF.loc[drug, :]     = EVAL_PERF(Y_LB_pred["Actual"], Y_LB_pred["RF"])
    RESULTS_LB_SVR.loc[drug, :]    = EVAL_PERF(Y_LB_pred["Actual"], Y_LB_pred["SVR"])
    RESULTS_LB_EN.loc[drug, :]     = EVAL_PERF(Y_LB_pred["Actual"], Y_LB_pred["EN"])
    RESULTS_LB_KNN.loc[drug, :]    = EVAL_PERF(Y_LB_pred["Actual"], Y_LB_pred["KNN"])
    RESULTS_LB_ENS.loc[drug, :]    = EVAL_PERF(Y_LB_pred["Actual"], Y_LB_pred["ENS"])
    RESULTS_LB_ENS12.loc[drug, :]  = EVAL_PERF(Y_LB_pred["Actual"], Y_LB_pred["ENS12"])
    RESULTS_LB_ENS123.loc[drug, :] = EVAL_PERF(Y_LB_pred["Actual"], Y_LB_pred["ENS123"])
    RESULTS_LB_ENS124.loc[drug, :] = EVAL_PERF(Y_LB_pred["Actual"], Y_LB_pred["ENS124"])
    RESULTS_LB_ENS134.loc[drug, :] = EVAL_PERF(Y_LB_pred["Actual"], Y_LB_pred["ENS134"])
    RESULTS_LB_ENS234.loc[drug, :] = EVAL_PERF(Y_LB_pred["Actual"], Y_LB_pred["ENS234"])
#### Whole loop ends...
dt = time() - dt;    print("Elapsed time = %0.4f sec." % dt)

RESULTS_LB_MEAN = pd.concat(((RESULTS_LB_RF.iloc[:N, :]).mean(axis = 0),     (RESULTS_LB_SVR.iloc[:N, :]).mean(axis = 0),
                             (RESULTS_LB_EN.iloc[:N, :]).mean(axis = 0),     (RESULTS_LB_KNN.iloc[:N, :]).mean(axis = 0),
                             (RESULTS_LB_ENS.iloc[:N, :]).mean(axis = 0),    (RESULTS_LB_ENS12.iloc[:N, :]).mean(axis = 0),
                             (RESULTS_LB_ENS123.iloc[:N, :]).mean(axis = 0), (RESULTS_LB_ENS124.iloc[:N, :]).mean(axis = 0),
                             (RESULTS_LB_ENS134.iloc[:N, :]).mean(axis = 0), (RESULTS_LB_ENS234.iloc[:N, :]).mean(axis = 0)), 
                            axis = 1, ignore_index = True)
RESULTS_LB_MEAN.columns = models
print("Mean performance for %d inhibitors = \n" % N, RESULTS_LB_MEAN.T)


#%%
# from sklearn.linear_model import LassoCV

# FS = Lasso(fit_intercept = False, normalize = False, alpha = 0.001, tol = 1e-3, 
#            selection = "random", random_state = 0)
# # FS = LassoCV(fit_intercept = True, normalize = True, tol = 1e-3, n_alphas = 200, cv = 5, 
# #              selection = "random", random_state = 0)
# aa = FS.fit(X_TR, y_TR).coef_
# print(sum(aa != 0))









   